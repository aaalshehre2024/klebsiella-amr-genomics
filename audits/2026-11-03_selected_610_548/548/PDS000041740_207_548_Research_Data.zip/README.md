# Collection 548 research data

**PDS000041740.207** · Source selection of 3 November 2026

Open `PDS000041740_207_548.xlsx` for the Excel view. The `data/` directory contains the corresponding machine-readable extract and provenance.

Use `data/main_results.tsv` for the 429 assemblies with full results. Its first 117 columns are the original Kleborate fields. The workbook presents selected fields together with the input row for the one unresolved assembly. Its 430 entries represent the input list. The five batch logs repeat the same 429 results on the eight shared fields and serve as a cross-check.

The full table provides assembly-level AMR and virulence marker calls, K/O typing and QC fields. Retain the source qualifiers, truncation and typing-confidence fields when selecting records for an analysis. The selected ZIP lacks a detailed hAMRonization table.

The 431 raw FASTA paths reduce to 430 distinct versioned FASTA accessions. Two paths refer to GCA_054407865.1. The unique-input manifest retains the path containing “(1)”. That accession is listed as skipped. The batch log reports a shell syntax error before a failed species check. The manifest preserves the record as technically unresolved. The 26 selected input paths whose outer folder uses GCF and whose FASTA uses GCA retain both labels.

## Record linkage and files

- `input_manifest.tsv` contains one row per versioned accession in this source's unique FASTA list. Use `record_status` to select the appropriate denominator.
- `input_path_evidence.tsv` retains original package-relative FASTA paths, outer directory identifiers, archive basenames and the line references needed to trace the input. An empty selected-manifest line identifies a path outside the unique-input selection.
- The result tables append `assembly_accession`, `source_member` and `source_line` to the original fields. Lines are one-based and include any headers and diagnostic lines. Preserve the source values when importing the TSV.
- `source_members.tsv` lists each source member's size and SHA-256. `audit.json` gives the source archive identity and the resulting record counts.
- `diagnostic_lines.tsv` records the three diagnostic messages and their positions in the original log.

The PDS identifier follows the package label. The extract validates linkage within this ZIP. Independent confirmation of membership in a frozen SNP-cluster snapshot requires its source metadata.

## Reproduce the TSVs

Use Python 3 and the exact original source ZIP. From the extracted research package, run this command with a new or empty destination.

```bash
python3 scripts/build_selected_kleborate.py 'PDS000041740_207_548_FINAL_kleborate_results(2).zip' rebuilt_548
```

Source ZIP SHA-256: `e37a999cc08118b0fdf1ff9d298f9884cb9979f7be9f5c3a8d97ec2000ac2389`

The script checks the input checksum and the internal joins before it exports the tables. `SHA256SUMS.txt` covers all other files in this research package. The research package is a derivative. The original ZIP is the input for rebuilding it.

[Versioned repository record](https://github.com/aaalshehre2024/klebsiella-amr-genomics/tree/f1c07bba7879815f1011aadf4e630f52a7965e90/audits/2026-11-03_selected_610_548)
