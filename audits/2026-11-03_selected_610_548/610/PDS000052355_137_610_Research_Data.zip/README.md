# Collection 610 research data

**PDS000052355.137** · Source selection of 3 November 2026

Open `PDS000052355_137_610.xlsx` for the Excel view. The `data/` directory contains the corresponding machine-readable extract and provenance.

Use `data/log_results.tsv` for the 503 observations from six batch logs. All 503 listed FASTAs match a log strain. The eight original fields are strain, species, N50, ST, virulence_score, resistance_score, num_resistance_classes and num_resistance_genes. The workbook presents all eight fields and row-level provenance.

The selected ZIP supplies neither a full main table nor a detailed hAMRonization table. Named AMR determinants, K/O types, individual virulence loci and their confidence calls are therefore unavailable for this extract. Preserve the ST labels exactly, including the single-locus variant suffixes.

The outer folder for GCA_036905415.1 uses the prefix GCF. The selected FASTA and the logged strain both use GCA. Both identifiers are preserved in the input evidence.

## Record linkage and files

- `input_manifest.tsv` contains one row per versioned accession in this source's unique FASTA list. Use `record_status` to select the appropriate denominator.
- `input_path_evidence.tsv` retains original package-relative FASTA paths, outer directory identifiers, archive basenames and the line references needed to trace the input. An empty selected-manifest line identifies a path outside the unique-input selection.
- The result tables append `assembly_accession`, `source_member` and `source_line` to the original fields. Lines are one-based and include any headers and diagnostic lines. Preserve the source values when importing the TSV.
- `source_members.tsv` lists each source member's size and SHA-256. `audit.json` gives the source archive identity and the resulting record counts.

The PDS identifier follows the package label. The extract validates linkage within this ZIP. Independent confirmation of membership in a frozen SNP-cluster snapshot requires its source metadata.

## Reproduce the TSVs

Use Python 3 and the exact original source ZIP. From the extracted research package, run this command with a new or empty destination.

```bash
python3 scripts/build_selected_kleborate.py 'PDS000052355_137_610_FINAL_kleborate_results(2).zip' rebuilt_610
```

Source ZIP SHA-256: `3fdfd66498b31b12b103b09726572800692cbd07ae747d6b4ce8e98d28fe9dab`

The script checks the input checksum and the internal joins before it exports the tables. `SHA256SUMS.txt` covers all other files in this research package. The research package is a derivative. The original ZIP is the input for rebuilding it.

[Versioned repository record](https://github.com/aaalshehre2024/klebsiella-amr-genomics/tree/f1c07bba7879815f1011aadf4e630f52a7965e90/audits/2026-11-03_selected_610_548)
