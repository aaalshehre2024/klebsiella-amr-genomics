Collection 610 · PDS000052355.137
Research data and reproducibility files · 5 November 2026

COVERAGE

The original selected FASTA manifest and the new full main and detailed AMR results have the same 503 versioned assembly accessions. The main table has 117 original fields and one row per assembly. The 32-column hAMRonization source table contains 13,826 rows, including exact repeats. There are 8,939 distinct complete AMR rows. Assembly accession.version is the unit of linkage and counting within this collection.

The historical source had eight log fields per accession. All 3,521 shared nonidentifier field values agree with the new main table. Six batch logs corroborate the assembly-level records. The uploaded main and AMR tables are the final merged outputs as supplied. Their upstream concatenation cannot be reconstructed from individual batch tables in this ZIP. The accession GCA_036905415.1 retains that FASTA and output ID despite a GCF-prefixed outer archive name.

FILES

610_profile.xlsx contains the coverage overview, accession profiles, full main table, observed joint profiles and field counts. The complete AMR data are supplied in the TSV files.

main_results.tsv and hamronization.tsv retain the exact bytes of the supplied final tables. In the main table, strain identifies the assembly result. In the AMR table, Input_file_name identifies the assembly that generated a reported annotation. Join through the versioned assembly accession in the accession profile, retaining the original strain names in the native tables.

hamronization_exact_unique.tsv retains the first occurrence of each distinct complete data row. This derivative is for sensitivity checks or inspection. Exact deduplication does not establish independent events, gene copy numbers or distinct biochemical determinants.

accession_profile.tsv connects each versioned assembly to prior evidence, current main-table row and raw and exact-distinct AMR record counts. It retains selected AMR and virulence markers, K/O calls, typing confidence and QC warnings.

profile_counts.tsv gives counts of the source field values, unflagged carbapenemase families and flagged tokens across the main-table assemblies. observed_joint_profiles.tsv counts same-assembly combinations of ST, K locus and confidence, O locus and confidence, and unflagged acquired carbapenemase families. Families are counted once per assembly. Consult the supplied script and the original allele strings for asterisk, caret and question-mark qualifiers. A source dash is a reported field value. Each typing-confidence category remains visible.

gene_variation_counts.tsv groups exact Gene_symbol, Mutation, Genetic_variation_type and Drug_class values. raw_records includes repeated rows. unique_assemblies counts each assembly once for a given combination. An assembly can contribute to multiple combinations, so their counts are not additive.

summary.json contains scope, coverage and previous-versus-current checks. source_members.tsv inventories the original ZIP members, sizes and SHA-256 digests. 
The hAMRonization records report Kleborate 3.2.4 and CARD 3.2.9. These are reported fields; a complete environment and reference-database fingerprint requires separate evidence. Genetic annotations and scores do not establish measured susceptibility or a clinical virulence phenotype.

REBUILD THE TABLES USING PYTHON 3

The full rerun ZIP (held separately) is PDS000052355_137_610_F_FINAL_kleborate_results.zip
Its SHA-256 digest is e53fc526598b0cdc873f78d1a620d2bff245881356d3e434fa09beb1cb716f6b.
Create a previous_610/ directory containing input_manifest.tsv and log_results.tsv from this immutable source:
https://github.com/aaalshehre2024/klebsiella-amr-genomics/tree/5d375292631ddc474371a0a6e1af04ca7317cd5d/audits/2026-11-03_selected_610_548/610

From the extracted research package, run the following using the original rerun ZIP at /path/to/source.zip. Choose a new output directory.
  python3 scripts/audit_610_update.py "/path/to/source.zip" previous_610 rebuilt/610
  python3 scripts/summarize_profiles.py rebuilt/610
  python3 scripts/browse_hamr.py rebuilt/610

The last command recreates gene_variation_counts.tsv and optional browser-sized parts of hamronization.tsv. The complete native table is included once here. Output TSV files use UTF-8 and tab separators. The Excel file is a separate viewing copy.

To verify the delivered files from the extracted package directory, run:
  sha256sum -c SHA256SUMS.txt

This package documents one processing collection. Study-wide isolate counts, biological cluster membership and phylogenetic mapping need their respective frozen metadata and assembly-to-tree crosswalk.
