# Reviewed release data

No research data are included here yet. Only place approved, non-identifiable,
permission-cleared analytical files here. Include the frozen manifest, data
dictionary, tables, and figure-source data needed to reproduce manuscript results.
Link large source archives to their persistent deposit and checksums. Never copy
unreviewed audit files here merely because the audit script exited successfully.
