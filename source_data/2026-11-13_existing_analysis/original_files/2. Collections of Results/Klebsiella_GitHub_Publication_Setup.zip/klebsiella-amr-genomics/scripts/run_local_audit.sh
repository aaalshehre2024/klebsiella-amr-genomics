#!/usr/bin/env bash
# Run as: bash /full/path/to/scripts/run_local_audit.sh "/path/to/Ready_for_analysis"
# No GitHub upload, no deletion, no Kleborate execution, no environment modification.
set -euo pipefail

PROJECT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
SOURCE="${1:-/mnt/c/Users/abu-r/OneDrive/New Computational 5 Data/Collections of Results/Ready_for_analysis}"

command -v python3 >/dev/null || { echo "STOP: python3 was not found." >&2; exit 2; }
[[ -d "$SOURCE" ]] || { printf 'STOP: Source folder not found: %s\n' "$SOURCE" >&2; exit 2; }
[[ -f "$PROJECT/scripts/audit_results.py" ]] || { echo "STOP: Audit script is missing." >&2; exit 2; }

# NUL-delimited listing handles spaces and parentheses in source paths.
LIST_FILE="$(mktemp)"
trap 'rm -f -- "$LIST_FILE"' EXIT
find "$SOURCE" -maxdepth 1 -type f -iname '*.zip' \
  ! -iname 'Klebsiella_GitHub_Analysis_Starter.zip' \
  ! -iname 'Klebsiella_GitHub_Publication_Setup.zip' -print0 | sort -z > "$LIST_FILE"
mapfile -d '' -t ZIP_FILES < "$LIST_FILE"
if (( ${#ZIP_FILES[@]} == 0 )); then
  printf 'STOP: No result ZIPs found directly in:\n%s\n' "$SOURCE" >&2
  echo 'Put selected final Kleborate result ZIPs here, not genome-download ZIPs or setup ZIPs.' >&2
  exit 2
fi
printf 'Selected ZIP files: %s\n' "${#ZIP_FILES[@]}"
printf '  %s\n' "${ZIP_FILES[@]}"
python3 "$PROJECT/scripts/test_project.py"

RUN_ID="$(date -u +%Y%m%dT%H%M%S)_$$"
INPUT="$PROJECT/input_raw/results_$RUN_ID"
OUTPUT="$PROJECT/outputs/audit_$RUN_ID"
[[ ! -e "$INPUT" && ! -e "$OUTPUT" ]] || { echo 'STOP: Run already exists.' >&2; exit 2; }
mkdir -p -- "$INPUT"
for z in "${ZIP_FILES[@]}"; do
  name="${z##*/}"
  [[ ! -e "$INPUT/$name" ]] || { echo "STOP: Duplicate destination name: $name" >&2; exit 2; }
  cp -- "$z" "$INPUT/$name"
done
cd -- "$PROJECT"
python3 scripts/audit_results.py --input-dir "$INPUT" --output-dir "$OUTPUT"
printf '%s\n' "$OUTPUT" > "$PROJECT/LOCAL_LAST_AUDIT.txt"
printf '\nAudit generated at: %s\n' "$OUTPUT"
[[ -f "$OUTPUT/QC_REPORT.md" ]] && cat "$OUTPUT/QC_REPORT.md"
printf '\nAudit execution finished. Review QC issues; this is NOT biological validation.\n'
