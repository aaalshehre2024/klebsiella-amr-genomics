#!/usr/bin/env python3
"""Run project tests from any directory; reject zero-test false success."""
from pathlib import Path
import sys
import unittest


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    tests = root / "tests"
    if not tests.is_dir():
        print(f"ERROR: Missing tests directory: {tests}", file=sys.stderr)
        return 2
    suite = unittest.defaultTestLoader.discover(
        start_dir=str(tests), pattern="test_*.py", top_level_dir=str(tests)
    )
    count = suite.countTestCases()
    if count == 0:
        print("ERROR: No tests discovered. Do not treat this as success.", file=sys.stderr)
        return 2
    print(f"Project: {root}\nDiscovered test cases: {count}", flush=True)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
