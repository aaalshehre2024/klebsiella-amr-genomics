#!/usr/bin/env python3
"""Audit selected Kleborate result ZIPs without modifying the original files.

Python >=3.9; standard library only. This is an audit/preliminary-summary tool,
not a validated biological interpretation or manuscript-generation pipeline.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import io
import json
import re
import sys
import zipfile
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

VERSION = "0.1.0"
MAX_MEMBER = 512 * 1024 * 1024
csv.field_size_limit(10 * 1024 * 1024)
ACC = re.compile(r"GC[AF]_\d+\.\d+")
EXT = re.compile(r"\.(?:fna|fasta|fa|fas|fsa)(?:\.gz)?$", re.I)
FIELDS = ("species", "species_match", "ST", "K_locus", "K_locus_confidence",
          "O_locus", "O_type", "O_locus_confidence", "resistance_score",
          "virulence_score", "QC_warnings")
META = ["audit_package", "audit_identity", "audit_accession", "audit_source_members"]
TECH = re.compile(r"Syntax error|Traceback|No such file or directory|command not found|"
                  r"Permission denied|Segmentation fault|\bKilled\b", re.I)
SKIP = re.compile(r"failed in check|does not match any specified species|Skipping to next assembly", re.I)


def identity(value: str) -> str:
    """Versioned accession is an assembly key, NOT a patient/isolate key.
    GCA/GCF pairs remain distinct pending an authoritative correspondence table.
    """
    name = value.strip().replace("\\", "/").rsplit("/", 1)[-1]
    match = ACC.search(name)
    return match.group(0) if match else "NAME:" + EXT.sub("", name)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def table(path: Path, rows: list[dict], fields: list[str], delimiter: str = ",") -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter=delimiter,
                                extrasaction="ignore", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, default=Path("input_raw"))
    parser.add_argument("--output-dir", type=Path)
    args = parser.parse_args()
    archives = sorted(p for p in args.input_dir.glob("*")
                      if p.is_file() and p.suffix.lower() == ".zip")
    if not archives:
        parser.error("No ZIPs found. Put selected FINAL RESULT ZIPs in the input directory, not genome ZIPs.")
    out = args.output_dir or Path("outputs") / datetime.now().strftime("audit_%Y%m%d_%H%M%S")
    # Refuse to overwrite an earlier audit or source files.
    if out.exists():
        parser.error(f"Output directory already exists: {out}. Choose a new output directory.")
    out.mkdir(parents=True)
    issues, inventory, output_files, conflicts, duplicate_archives = [], [], [], [], []
    raw_records, accepted_records, missing_inputs, unexpected_results = [], [], [], []
    manifest_rows, distributions, cross_duplicates, log_events = [], [], [], []
    all_columns: set[str] = set()
    packages_by_key: dict[str, list[dict]] = defaultdict(list)
    hashes: dict[str, str] = {}

    def issue(package: str, kind: str, detail: str, member: str = "") -> None:
        issues.append(dict(package=package, issue=kind, member=member, detail=detail))

    for archive in archives:
        package = archive.stem
        print(f"Auditing: {archive.name}", flush=True)
        digest = sha256(archive)
        if digest in hashes:
            duplicate_archives.append(dict(archive=archive.name, identical_to=hashes[digest], sha256=digest))
            issue(package, "duplicate_archive_omitted", f"Byte-identical to {hashes[digest]}")
            continue
        hashes[digest] = archive.name
        manifest_rows.append(dict(archive=archive.name, sha256=digest, package_id=package,
                                  collection_id_with_version="", kmer_group_with_version="",
                                  cohort_role="REQUIRES_REVIEW", metadata_export_date="",
                                  assembly_download_date="", frozen_metadata_file="", newick_file="",
                                  tree_linkage_verified="NOT_VERIFIED", include_decision="PENDING"))
        candidates: dict[str, list[tuple[dict, str]]] = defaultdict(list)
        input_sets: list[tuple[str, set[str]]] = []
        main_file_count = hamr_file_count = bad_rows = 0
        log_only_rows = 0
        try:
            with zipfile.ZipFile(archive) as z:
                infos = [x for x in z.infolist() if not x.is_dir()]
                for info in infos:
                    base = PurePosixPath(info.filename).name.lower()
                    is_main = ("klebsiella_pneumo_complex_output" in base and
                               base.endswith((".txt", ".tsv")))
                    is_hamr = ("hamronization_output" in base and
                               base.endswith((".txt", ".tsv")))
                    is_input = base == "all_available_fasta_paths_unique.txt"
                    is_log = base.endswith(".log")
                    if not (is_main or is_hamr or is_input or is_log):
                        continue
                    if info.file_size > MAX_MEMBER:
                        issue(package, "oversize_member_not_read", str(info.file_size), info.filename)
                        continue
                    try:
                        with z.open(info) as binary:
                            text = io.TextIOWrapper(binary, encoding="utf-8-sig", errors="strict", newline="")
                            if is_input:
                                ids = {identity(line) for line in text if line.strip()}
                                input_sets.append((info.filename, ids))
                                continue
                            if is_log:
                                for lineno, line in enumerate(text, 1):
                                    if TECH.search(line) or SKIP.search(line):
                                        kind = "technical_error" if TECH.search(line) else "processing_or_species_review"
                                        log_events.append(dict(package=package, member=info.filename,
                                                               line_number=lineno, event=kind,
                                                               message=line.rstrip()))
                                    if re.match(r"^GC[AF]_\d+\.\d+", line):
                                        log_only_rows += 1
                                continue
                            reader = csv.reader(text, delimiter="\t")
                            header = next(reader, [])
                            if len(header) != len(set(header)) or not header:
                                issue(package, "invalid_header", "Empty or duplicated column names", info.filename)
                                continue
                            required = {"strain", "species", "ST"} if is_main else {"Input_file_name", "Gene_symbol"}
                            if not required.issubset(header):
                                issue(package, "unexpected_header", "Missing " + str(sorted(required - set(header))), info.filename)
                                continue
                            if is_main:
                                main_file_count += 1
                                all_columns.update(header)
                            else:
                                hamr_file_count += 1
                            count, ids, versions, dbs, dbversions = 0, set(), set(), set(), set()
                            for lineno, values in enumerate(reader, 2):
                                if not values or not any(values) or values == header:
                                    continue
                                if len(values) != len(header):
                                    bad_rows += 1
                                    issue(package, "malformed_row", f"Line {lineno}: {len(values)} fields; expected {len(header)}", info.filename)
                                    continue
                                row = dict(zip(header, values))
                                name = row["strain" if is_main else "Input_file_name"].strip()
                                if not name:
                                    bad_rows += 1
                                    issue(package, "empty_identity", f"Line {lineno}", info.filename)
                                    continue
                                key = identity(name)
                                ids.add(key)
                                count += 1
                                if is_main:
                                    candidates[key].append((row, info.filename))
                                    raw_records.append(dict(audit_package=package, audit_identity=key,
                                                            audit_accession=key if ACC.fullmatch(key) else "",
                                                            audit_source_members=info.filename, **row))
                                else:
                                    versions.add(row.get("Software_version", "NOT_REPORTED"))
                                    dbs.add(row.get("Reference_database_name", "NOT_REPORTED"))
                                    dbversions.add(row.get("Reference_database_version", "NOT_REPORTED"))
                            output_files.append(dict(package=package, member=info.filename,
                                                     output_type="main" if is_main else "hAMRonization",
                                                     data_rows=count, distinct_assembly_keys=len(ids),
                                                     software_versions=";".join(sorted(versions)),
                                                     database_names=";".join(sorted(dbs)),
                                                     database_versions=";".join(sorted(dbversions))))
                    except (OSError, UnicodeError, csv.Error, zipfile.BadZipFile, RuntimeError, EOFError) as exc:
                        issue(package, "member_read_error", str(exc), info.filename)
        except (OSError, zipfile.BadZipFile) as exc:
            issue(package, "archive_read_error", str(exc))

        good: dict[str, dict] = {}
        for key, entries in sorted(candidates.items()):
            # Compare every reported field except filename/strain. Differences in
            # schemas or any feature are conflicts, not silently resolved.
            signatures = {tuple(sorted((k, v) for k, v in row.items() if k != "strain"))
                          for row, _ in entries}
            if len(signatures) != 1:
                conflicts.append(dict(package=package, identity=key,
                                      source_members=";".join(sorted({m for _, m in entries})),
                                      variants=len(signatures)))
                issue(package, "conflicting_main_results", key)
                continue
            row = entries[0][0]
            record = dict(audit_package=package, audit_identity=key,
                          audit_accession=key if ACC.fullmatch(key) else "",
                          audit_source_members=";".join(sorted({m for _, m in entries})), **row)
            accepted_records.append(record)
            good[key] = record
            packages_by_key[key].append(record)
        expected = None
        if input_sets:
            expected = input_sets[0][1]
            if any(ids != expected for _, ids in input_sets[1:]):
                issue(package, "conflicting_input_manifests", "Do not select a denominator until manifests are reconciled.")
                expected = None
        else:
            issue(package, "input_manifest_missing", "No all_available_fasta_paths_unique.txt; completion cannot be established.")
        if not main_file_count:
            issue(package, "main_output_missing", f"Logs are not a substitute for the full table (log summary lines: {log_only_rows}).")
        if not hamr_file_count:
            issue(package, "hamronization_output_missing", "Not evidence of absence of AMR determinants.")
        if expected is not None:
            for key in sorted(expected - good.keys()):
                missing_inputs.append(dict(package=package, identity=key,
                                           status="conflicting_results" if key in candidates else "not_in_main_output"))
            for key in sorted(good.keys() - expected):
                unexpected_results.append(dict(package=package, identity=key))
            if expected - good.keys():
                issue(package, "unresolved_inputs", str(len(expected - good.keys())))
            if good.keys() - expected:
                issue(package, "unexpected_result_identifiers", str(len(good.keys() - expected)))
        inventory.append(dict(package=package, archive=archive.name, sha256=digest,
                              main_output_files=main_file_count, hamronization_output_files=hamr_file_count,
                              input_distinct_keys="UNKNOWN" if expected is None else len(expected),
                              main_distinct_keys=len(candidates), nonconflicting_main_keys=len(good),
                              conflicting_main_keys=len(candidates)-len(good), malformed_rows=bad_rows,
                              unresolved_input_keys="UNKNOWN" if expected is None else len(expected-good.keys()),
                              unexpected_result_keys="UNKNOWN" if expected is None else len(good.keys()-expected)))
        for field in FIELDS:
            counts = Counter(row.get(field, "<NOT_REPORTED>") or "<MISSING>" for row in good.values())
            for value, n in counts.most_common():
                distributions.append(dict(package=package, feature=field, raw_value=value, n=n,
                                          denominator_nonconflicting_main=len(good),
                                          percent=round(100*n/len(good), 4)))

    for key, entries in sorted(packages_by_key.items()):
        if len(entries) < 2:
            continue
        feature_sigs = {tuple(sorted((k, v) for k, v in row.items()
                                     if k not in META and k != "strain")) for row in entries}
        cross_duplicates.append(dict(identity=key, package_count=len(entries),
                                     packages=";".join(r["audit_package"] for r in entries),
                                     features_agree="YES" if len(feature_sigs)==1 else "NO_OR_DIFFERENT_SCHEMA"))
    fields = META + (["strain"] if "strain" in all_columns else []) + sorted(all_columns - {"strain"})
    table(out/"main_rows_with_provenance.tsv", raw_records, fields, "\t")
    table(out/"nonconflicting_main_records.tsv", accepted_records, fields, "\t")
    table(out/"package_inventory.csv", inventory, ["package","archive","sha256","main_output_files",
        "hamronization_output_files","input_distinct_keys","main_distinct_keys","nonconflicting_main_keys",
        "conflicting_main_keys","malformed_rows","unresolved_input_keys","unexpected_result_keys"])
    table(out/"output_file_inventory.csv", output_files, ["package","member","output_type","data_rows",
        "distinct_assembly_keys","software_versions","database_names","database_versions"])
    table(out/"qc_issues.csv", issues, ["package","issue","member","detail"])
    table(out/"within_package_conflicts.csv", conflicts, ["package","identity","source_members","variants"])
    table(out/"cross_package_duplicates.csv", cross_duplicates, ["identity","package_count","packages","features_agree"])
    table(out/"byte_identical_archives.csv", duplicate_archives, ["archive","identical_to","sha256"])
    table(out/"unresolved_inputs.csv", missing_inputs, ["package","identity","status"])
    table(out/"unexpected_result_identifiers.csv", unexpected_results, ["package","identity"])
    table(out/"log_review.csv", log_events, ["package","member","line_number","event","message"])
    table(out/"preliminary_raw_value_distributions.csv", distributions, ["package","feature","raw_value","n",
        "denominator_nonconflicting_main","percent"])
    table(out/"collection_manifest_TO_COMPLETE.csv", manifest_rows, ["archive","sha256","package_id",
        "collection_id_with_version","kmer_group_with_version","cohort_role","metadata_export_date",
        "assembly_download_date","frozen_metadata_file","newick_file","tree_linkage_verified","include_decision"])
    run_meta = {"script_version":VERSION,"timestamp_utc":datetime.now(timezone.utc).isoformat(),
                "python_version":sys.version,"input_zip_count":len(archives),
                "packages_audited":len(inventory),"byte_identical_archives_omitted":len(duplicate_archives),
                "nonconflicting_collection_assembly_records":len(accepted_records),
                "distinct_assembly_keys_among_nonconflicting_records":len(packages_by_key),
                "assembly_keys_in_multiple_packages":len(cross_duplicates),"qc_issue_count":len(issues),
                "status":"PROVISIONAL_AUDIT_NOT_MANUSCRIPT_READY"}
    (out/"run_metadata.json").write_text(json.dumps(run_meta,indent=2)+"\n",encoding="utf-8")
    report = f"""# Kleborate audit — provisional, not manuscript-ready

Selected input ZIPs: {len(archives)}. Distinct byte-level packages audited: {len(inventory)}.
Nonconflicting collection–assembly records: {len(accepted_records)}.
Distinct assembly keys represented in those records: {len(packages_by_key)}.
Assembly keys found in multiple packages: {len(cross_duplicates)}.
QC issue records: {len(issues)}. Log events requiring review: {len(log_events)}.

## Required interpretation

A result package is NOT automatically a distinct biological collection. Complete
`collection_manifest_TO_COMPLETE.csv` using the original frozen source metadata.
The script does not verify NCBI collection membership, GCA/GCF pairing, or tree-tip
linkage. Assembly identifiers are not automatically unique isolate identifiers.

`nonconflicting_main_records.tsv` excludes within-package conflicting keys, but it
is still provisional: cross-package overlaps, provenance and quality flags require
review. `main_rows_with_provenance.tsv` retains all readable source rows.

`preliminary_raw_value_distributions.csv` preserves literal output values and has
no clinical or biological positive/negative classification. Missing fields are not
absence, zero is not a universal negative code, and truncated/uncertain allele
suffixes have not been reclassified. Do not calculate pooled virulence or AMR
frequencies until version-specific definitions and feature denominators are locked.

`output_file_inventory.csv` counts hAMRonization rows per file. These rows are NOT
genome counts or counts of distinct genes; multiple candidate files may repeat the
same results. The tool does not merge or interpret hAMRonization calls.

`unresolved_inputs.csv` is based on exact versioned assembly keys where possible;
it does not silently turn skipped/failed inputs into biological exclusions. A shell
syntax error or missing file is a technical failure, not a taxonomic exclusion.
Empty logs or equal total counts do not verify the membership of a frozen cohort.

## Next actions

Review `qc_issues.csv`, `within_package_conflicts.csv`, `cross_package_duplicates.csv`,
`unexpected_result_identifiers.csv`, `unresolved_inputs.csv`, and `log_review.csv`.
Reconcile cohort and snapshot versions, recover missing outputs, and document a
collection-level inclusion decision. Only then create locked manuscript tables.

Original ZIPs are unchanged. This program does not rerun Kleborate, push to GitHub,
or write manuscript findings. SHA-256 values are in `package_inventory.csv`.
"""
    (out/"QC_REPORT.md").write_text(report,encoding="utf-8")
    print(f"\nAudit saved to: {out.resolve()}\nRead QC_REPORT.md before using any counts.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
