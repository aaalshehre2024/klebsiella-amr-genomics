# Manuscript status

The working title is in the repository README. No final manuscript or accepted
article is included. Draft Results only after the author approves the cohort and
QC decisions. Describe completed methods accurately; keep proposed analyses out of
past-tense Methods. Every numerical claim must have a source table, denominator,
and script recorded in the evidence map.
