# Proposed analysis plan for author approval

**Status:** prospective next steps based on exploratory work already seen; not a
preregistration and not evidence that these analyses have been performed. Preserve
the date and reason for every later change. Do not select rules just to maximize an
interesting result, and do not call this plan prespecified before the original runs.

## 1. Establish scientific cohort identity before pooling

For every result package, identify the biological collection(s), source file,
versioned PDS/PDG/PDT identifiers, download date, analysis date, input-list checksum,
and mapping to versioned GCA/GCF accessions. Multiple local run folders can represent
parts of one biological collection. PDG is an organism-group identifier; it cannot
replace a PDS identifier in a tree-specific claim. Verify metadata/tree membership
rather than using folder counts. Do not mix newer snapshots with older trees.

Separate database records, downloaded paths, unique versioned assemblies,
biological isolates, and collection-assembly observations. Reconcile duplicate
assemblies and documented GenBank/RefSeq pairs without deleting prefixes or version
suffixes. Record selection criteria for primary, extended, and unmapped cohorts.

## 2. Technical and output audit

Review incompatible headers, truncated/malformed rows, conflicting calls, missing
main/hAMRonization outputs, and input-output identity mismatches. A nonzero command
exit, shell syntax error, inaccessible path, or missing output is a technical issue,
not evidence of non-Klebsiella species. Require a valid species result or explicit
investigation before accepting a biological exclusion. Record unresolved technical
failures separately. Logs do not supply unreported K/O or gene-level features.

## 3. Main analytical questions

| Proposed result | Required evidence | Proposed denominator |
|---|---|---|
| Assembly availability and final eligibility | Frozen source records, accessions, QC decisions | Each recorded step, not file counts |
| Collection-specific ST/K/O composition | Main output and typing-confidence rules | Eligible assemblies with explicit missing category |
| Carbapenemase-family co-detection and exact variants | Verified determinant calls and flag interpretation | Eligible genomes, not hit rows |
| Resistance-virulence marker co-detection | Same-assembly calls and a written operational rule | Assemblies with both evidence layers available |
| Within-ST heterogeneity and architecture contrasts | Adequate within-ST observations and mapped collection metadata | Defined within-ST strata |
| Tree-mapped architecture distributions | Exact, version-aware metadata-to-Newick linkage | Matched tips; unmatched tips reported |

## 4. Interpretation and sensitivity analyses

Preserve raw gene tokens and confidence/truncation flags. Freeze a version-specific
mapping table before final summaries. Distinguish the study's proposed categorical
architecture classification from Kleborate's scores; an absent annotation must not
be used as a low-resistance measurement. Avoid treating ordinal score codes as an
interval scale without justification.

For convergence, compare an explicitly defined carbapenemase-plus-aerobactin profile
with broader descriptive virulence co-detection; report rmp loci and gene-integrity
flags separately. Neither yersiniabactin alone nor a high software score establishes
functional hypervirulence. Do not infer plasmid linkage from assembly co-detection.
Do not equate genotype-based resistance classes with phenotypic MDR definitions.

Assess sensitivity to global deduplication, confident-only calls, complete-output
collections, alternate documented parsing rules, primary versus extended cohorts,
and large-collection dominance. Consider availability bias by comparing included and
unavailable assemblies on observable frozen metadata. These analyses are proposals,
not completed results. Do not invent AST validation, patient outcomes, or sampling
representativeness.

## 5. Statistical scope

Begin with within-collection counts, denominators, missingness, and effect sizes.
Avoid treating all assemblies as independent random population samples. Any formal
comparison must address sampling design, lineage/collection dependence, and multiple
comparisons. The presence of selected SNP clusters makes strong ST dominance partly
expected; dominance alone is not proof of a novel epidemiological discovery.

## 6. Reporting gate

Every numerical manuscript claim must map to a versioned table cell, data subset,
and executable script. Mark each planned analysis as proposed, implemented,
validated, or reported. No unchanged earlier chat total is a final source of truth.
