# Analyst instructions

Read the README, current audit report, source manifests, and analysis plan before
writing numerical findings. The earlier chat summaries are not the source of truth.
Use only verified tables and clearly distinguish current findings from proposed
analyses. Do not fill missing evidence, version information, cohort membership,
or unknown dates with assumptions.

Reconcile packages with collections; technical batches with biological isolates;
PDG organism groups with PDS SNP clusters; and assembly accessions with verified
isolate identifiers. Report conflicting calls and mixed versions. Review technical
failures before accepting species exclusions. Missing output is not a negative call.

Produce the denominator/provenance table first. Only after author approval, implement
the biological parsing, summaries, appropriate sensitivity analyses, and verified
tree mapping. Do not portray the supplied audit script as a complete downstream
analysis pipeline. Keep exact traceability for every manuscript number. Methods must
describe what actually ran, not proposed steps. Verify citations against primary
sources and describe AI-assisted work accurately.
