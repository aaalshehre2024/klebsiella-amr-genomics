# Ubuntu setup

Use `START_HERE.md` in this folder for the current instructions. The prior audit
code remains unchanged. The test runner and local wrapper added in this setup avoid
reliance on the terminal's current folder or shell variables set in earlier windows.
