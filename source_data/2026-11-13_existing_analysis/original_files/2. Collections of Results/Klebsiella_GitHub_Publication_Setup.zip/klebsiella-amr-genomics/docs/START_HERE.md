# Start here: upload code, audit locally, review evidence

This setup package has no private research inputs or results. It was prepared for
`aaalshehre2024/klebsiella-amr-genomics`. Generating it did not modify GitHub.
The earlier audit program and synthetic tests are retained unchanged.

## Upload the starter structure

Extract `Klebsiella_GitHub_Publication_Setup.zip` on Windows. Open the inner
`klebsiella-amr-genomics` folder. Upload its CONTENTS to the repository root through
GitHub's upload-existing-files interface. Do not upload the ZIP itself or the enclosing
parent folder. Review every selected file. The root should contain `README.md`,
`CITATION.cff`, `.gitignore`, `scripts/`, `tests/`, `metadata/`, `docs/`,
`manuscript/`, and `release_data/`. No raw research data are in this starter.
GitHub does not retain empty folders; the README/placeholder files preserve structure.

For an empty repository, use its "uploading an existing file" link. After the first
commit, use "Add file" then "Upload files". A suggested first commit message is:
`Initialize audit-first Klebsiella manuscript repository`.

## Local setup in Ubuntu

Save the setup ZIP into the known Windows directory:
`C:\Users\abu-r\OneDrive\New Computational 5 Data\Collections of Results`.
Do not type this Windows path by itself as an Ubuntu command.

```bash
SETUP_ZIP="/mnt/c/Users/abu-r/OneDrive/New Computational 5 Data/Collections of Results/Klebsiella_GitHub_Publication_Setup.zip"
unzip -n "$SETUP_ZIP" -d "$HOME/klebsiella-publication-setup"
python3 "$HOME/klebsiella-publication-setup/klebsiella-amr-genomics/scripts/test_project.py"
```

The new directory is separate from the original `$HOME/klebsiella-amr-genomics`.
No old results are moved or overwritten. Run these commands only after saving the ZIP.

Place only the chosen final Kleborate result ZIPs directly inside:
`C:\Users\abu-r\OneDrive\New Computational 5 Data\Collections of Results\Ready_for_analysis`.
Then run:

```bash
bash "$HOME/klebsiella-publication-setup/klebsiella-amr-genomics/scripts/run_local_audit.sh" \
  "/mnt/c/Users/abu-r/OneDrive/New Computational 5 Data/Collections of Results/Ready_for_analysis"
```

The wrapper locates its own program folder, tests the program, rejects an empty input
folder, copies originals to a timestamped local folder, and creates a non-overwriting
audit. It does not reinstall or rerun Kleborate, change your conda environment, or
upload anything to GitHub. A successful execution is not a passed scientific audit.

## Read and share the audit

```bash
PROJECT="$HOME/klebsiella-publication-setup/klebsiella-amr-genomics"
AUDIT="$(cat "$PROJECT/LOCAL_LAST_AUDIT.txt")"
cat "$AUDIT/QC_REPORT.md"
```

Review QC issues and the manifest locally. Share the audit with the analyst before
publishing results. `.gitignore` blocks normal Git commits of `outputs/`; manual
browser uploads still require careful human review. Once approved, copy intended
public analytical tables into `release_data/` and update the documentation.

For a journal release, follow `docs/RELEASE_PLAN.md`. Do not label the current
starter as v1.0.0, complete, validated, or publication-ready.
