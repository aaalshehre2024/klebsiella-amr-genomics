# Submission release plan

This is a release plan, not a statement that data have been deposited.

## Before release

Resolve or transparently account for every inclusion/exclusion decision, conflicting
record, duplicate, missing output, and accession mismatch. Freeze the final cohort,
analysis rules, data dictionary, processed tables, figure-source tables, scripts,
exact environment information, and software/database versions. Obtain approval for
public sharing and select code/data licensing consistent with rights and source
terms. Verify authors and contributors in `CITATION.cff`.

Create a figure/table evidence map in `metadata/figure_table_map_template.tsv`.
Tests must be nonempty and successful, with the interpreter recorded. Run the full
analysis from the frozen inputs in a clean environment and compare the regenerated
outputs. Synthetic audit tests alone are insufficient for this requirement.

## Archive the manuscript version

Commit the approved content and record the exact commit. Use a versioned release
such as `v1.0.0-submission` only when the manuscript dataset is actually frozen.
Link an appropriate public GitHub repository to Zenodo and archive that release,
or make a separate documented deposit. A DOI is assigned by the archive; never
invent one. Do not assume raw files excluded by `.gitignore`, local folders, or
separate GitHub release assets are present in the archived source snapshot: inspect
the deposited files explicitly. Large data can be deposited separately with links
and checksums.

Cite the version-specific DOI/record that corresponds to the manuscript results,
and keep later corrections as new versions. Update the CFF and README with verified
metadata without misrepresenting the contents of the archived release.

## Data and code availability text: fill only after deposit

The public genome records analyzed in this study are identified by versioned
accessions in [manifest]. The frozen study-specific metadata, verified tree files,
processed analytical tables, mapping rules, and code supporting the reported
results are available in [repository/archive, version, DOI]. Source genome assemblies
are available from NCBI under the listed accessions. [State any justified access or
redistribution restrictions and the route to permitted access.]

This text must match the actual deposited files. Do not say that data sharing is
inapplicable just because the source genomes were public.

## AI-assisted work

Keep an accurate record of AI assistance with planning, code, drafting, analysis,
and visualization, as applicable, and the human checks performed. The disclosure
must match actual use and the journal policy at submission; do not describe all use
as language editing when coding or analytical assistance also occurred. Do not
claim independent human validation unless it has happened.
