# Licensing and privacy: author decisions required

This package deliberately does not apply a code licence or a data licence on the
author's behalf. A public GitHub location and an open-source licence are different
things. The project team should decide the licence for its original code and the
terms for its original processed data after checking institutional requirements,
contributor rights, and third-party source terms. Preserve attribution and third-party
licences; a blanket code licence cannot automatically relicense source data.

Before upload, inspect for credentials, tokens, personal identifiers, unpublished
patient data, local account paths, and material without sharing permission. A public
repository exposes committed content; deleting a file later need not remove it from
history or copies. `.gitignore` does not sanitize already tracked files or browser
uploads. Put only reviewed data into `release_data/`; keep originals locally and in
an approved archive. Do not add passwords or access tokens to chat or documentation.

See GitHub's official licensing documentation in `SOURCES.md`.
