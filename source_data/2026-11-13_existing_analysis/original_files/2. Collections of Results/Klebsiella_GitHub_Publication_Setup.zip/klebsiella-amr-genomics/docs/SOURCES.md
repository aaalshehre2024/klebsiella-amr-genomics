# Official documentation consulted

Checked for this setup: 2 November 2026. Live documentation may change. These
sources support repository/reporting guidance, not a claim that the underlying
research data have been validated.

- MDPI Research and Publication Ethics / Research Data Policies:
  https://www.mdpi.com/ethics
- MDPI Author Layout Style Guide, Data Availability Statement:
  https://www.mdpi.com/authors/layout
- Antibiotics author instructions (journal-specific page was rate-limited during this check;
  consult it directly before submission):
  https://www.mdpi.com/journal/antibiotics/instructions
- GitHub file uploads:
  https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
- GitHub citation files:
  https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-citation-files
- GitHub licensing:
  https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/licensing-a-repository
- GitHub archiving and citation:
  https://docs.github.com/en/repositories/archiving-a-github-repository/referencing-and-citing-content
- Zenodo GitHub integration:
  https://help.zenodo.org/docs/github/enable-repository/
- Zenodo release archiving:
  https://help.zenodo.org/docs/github/archive-software/github-upload/
- NCBI Pathogen Detection documentation (PDG/PDS/PDT identifiers and versioning):
  https://www.ncbi.nlm.nih.gov/pathogens/pathogens_help/
- Kleborate module documentation (inspect the release used for analysis; the live page
  is not proof of historical defaults):
  https://kleborate.readthedocs.io/en/latest/kpsc_modules.html
