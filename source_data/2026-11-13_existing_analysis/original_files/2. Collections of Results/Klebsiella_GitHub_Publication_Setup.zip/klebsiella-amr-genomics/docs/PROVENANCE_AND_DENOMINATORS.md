# Provenance and denominators

Complete the audit-generated `collection_manifest_TO_COMPLETE.csv` from the frozen
source metadata, then version the approved copy. The inherited
`kmer_group_with_version` field records the PDG organism-group accession, not a
separate PDS SNP cluster. No downloaded-path count alone establishes isolate count.

For each package, also document the exact retrieval query/selection rule, metadata
export date, assembly-download date, analysis date, result SHA-256, collection ID
and version, technical batch ID, source metadata filename, tree filename and hash,
Kleborate executable version, dependency versions, database releases or file hashes,
and author-approved include/exclude decision. Unknown fields remain unknown.

Build a per-record accession correspondence table linking the source record/PDT,
BioSample when supplied, assembly accession with version, technical package, PDS
version when verified, input checksum when available, analysis eligibility, output
availability, and exclusion reason. Review one-to-many mappings explicitly.

Record both independent assemblies and collection-assembly observations when the
same assembly appears in multiple contexts. Paired GCA/GCF records and assembly
versions require source-supported reconciliation. Keep excluded, unresolved,
unavailable, and not-applicable categories separate.

Use eligibility-specific denominators: all selected source records; available
assemblies; successfully processed assemblies; confident typing calls; valid gene
annotations; complete resistance/virulence evidence; verified tree-linked tips.
Never infer an absent gene from an absent table or a missing cell.
