# Metadata

`collections_template.csv` is the original starter template, not a completed cohort
manifest. Populate the audit-generated manifest with source-verified identities and
versions, then commit an approved copy. Use `figure_table_map_template.tsv` to map
every main figure/table to its exact inputs, rules, code, and denominator.

Do not infer a cluster from folder numbers. Record unknown values rather than
silently filling them from earlier narrative summaries.
