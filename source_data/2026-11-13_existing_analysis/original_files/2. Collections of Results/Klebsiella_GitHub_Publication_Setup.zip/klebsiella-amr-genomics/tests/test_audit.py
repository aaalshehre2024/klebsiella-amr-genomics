"""Synthetic tests only; not biological validation of Kleborate calls."""
import csv
import json
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts' / 'audit_results.py'
HEADER = 'strain\tspecies\tST\tK_locus\tresistance_score\tvirulence_score\n'
MAIN = 'final_full_results/test_FINAL_klebsiella_pneumo_complex_output.txt'
HAMR = 'final_full_results/test_FINAL_hAMRonization_output.txt'


def record(accession, st='ST_TEST'):
    return f'{accession}_genomic\tKlebsiella pneumoniae\t{st}\tKL_TEST\t2\t0\n'


def write_zip(path, content):
    with zipfile.ZipFile(path, 'w') as z:
        for name, text in content.items():
            z.writestr(name, text)


class AuditTests(unittest.TestCase):
    def test_overlap_conflicts_and_missing_outputs(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            inp = root/'input'; inp.mkdir()
            out = root/'audit'
            main_a = HEADER + record('GCA_000000001.1') + record('GCA_000000002.1')
            write_zip(inp/'package_A.zip', {
                MAIN: main_a,
                'batch_results/batch_000/klebsiella_pneumo_complex_output.txt': main_a,
                HAMR: 'Input_file_name\tGene_symbol\tSoftware_version\nGCA_000000001.1_genomic\tTEST\t3.2.4\n',
                'all_available_fasta_paths_unique.txt': '/path with space/GCA_000000001.1_genomic.fna\n/path/GCA_000000002.1_genomic.fna\n'})
            # A repeated archive is not counted twice.
            (inp/'package_A_copy.zip').write_bytes((inp/'package_A.zip').read_bytes())
            write_zip(inp/'package_B.zip', {MAIN: HEADER + record('GCA_000000002.1') + record('GCF_000000002.1'),
                'all_available_fasta_paths_unique.txt': 'GCA_000000002.1_genomic.fna\nGCF_000000002.1_genomic.fna\n'})
            write_zip(inp/'package_C.zip', {
                MAIN: HEADER + record('GCA_000000003.1', 'ST_1'),
                'batch_results/batch_000/klebsiella_pneumo_complex_output.txt': HEADER + record('GCA_000000003.1','ST_2'),
                'all_available_fasta_paths_unique.txt': 'GCA_000000003.1_genomic.fna\n',
                'batch_logs/batch_000.log': '/bin/sh: 1: Syntax error: "(" unexpected\n'})
            write_zip(inp/'package_D.zip', {'batch_logs/batch_000.log': 'GCA_000000004.1_genomic summary only\n'})
            run = subprocess.run([sys.executable, str(SCRIPT), '--input-dir', str(inp), '--output-dir', str(out)], capture_output=True, text=True)
            self.assertEqual(run.returncode, 0, run.stderr)
            meta = json.loads((out/'run_metadata.json').read_text())
            self.assertEqual(meta['byte_identical_archives_omitted'], 1)
            self.assertEqual(meta['nonconflicting_collection_assembly_records'], 4)
            self.assertEqual(meta['distinct_assembly_keys_among_nonconflicting_records'], 3)
            self.assertEqual(meta['assembly_keys_in_multiple_packages'], 1)
            with (out/'within_package_conflicts.csv').open() as f:
                conflicts = list(csv.DictReader(f))
            self.assertEqual(len(conflicts), 1)
            with (out/'qc_issues.csv').open() as f:
                issues = list(csv.DictReader(f))
            self.assertTrue(any(x['issue']=='main_output_missing' for x in issues))
            self.assertTrue(any(x['issue']=='hamronization_output_missing' for x in issues))
            self.assertTrue(any(x['issue']=='unresolved_inputs' for x in issues))
            self.assertIn('technical_error', (out/'log_review.csv').read_text())
            # Existing reports cannot be overwritten.
            rerun = subprocess.run([sys.executable, str(SCRIPT), '--input-dir', str(inp), '--output-dir', str(out)], capture_output=True)
            self.assertNotEqual(rerun.returncode, 0)

    def test_empty_input_is_error(self):
        with tempfile.TemporaryDirectory() as d:
            run = subprocess.run([sys.executable, str(SCRIPT), '--input-dir', d], capture_output=True)
            self.assertNotEqual(run.returncode, 0)


if __name__ == '__main__':
    unittest.main()
