# Klebsiella AMR genomics

## Study and status

**Working manuscript title:** Database-Derived Genomic Mapping of Carbapenemase,
Multidrug-Resistance, and Virulence Architectures across Selected *Klebsiella
pneumoniae* SNP-Cluster Collections.

**Intended journal:** *Antibiotics* (MDPI).
**Repository:** https://github.com/aaalshehre2024/klebsiella-amr-genomics
**Stage:** development and data reconciliation; not a final analytical release.

This repository is intended to document the reuse of public NCBI Pathogen Detection
metadata, available assembly-level Kleborate outputs, and verified database-derived
Newick trees. No research results, final cohort totals, manuscript acceptance, or
completed biological validation are claimed by this setup package.

The included audit program inventories result ZIPs, validates basic table structure,
flags conflicting records, reports repeated assembly identifiers, and creates
provisional raw-value summaries. It does not rerun Kleborate, reconstruct trees,
classify functional resistance/virulence, perform hypothesis testing, or generate
publication-ready biological conclusions. Its Python-standard-library implementation
is intended for Python 3.9 or later; record the interpreter actually used.

## Start locally

```bash
# This test runner works from any current working directory.
python3 scripts/test_project.py

# This wrapper tests the code, copies selected result ZIPs into a new local folder,
# and runs a new non-overwriting audit.
bash scripts/run_local_audit.sh "/path/to/Ready_for_analysis"
```

The path must contain completed Kleborate **result** ZIPs directly, not NCBI genome
ZIPs, the setup archive, or nested result archives. Keep the originals unchanged.
See `docs/START_HERE.md` for the known Windows/Ubuntu locations for this project.

## What is present and what remains to be added

| Component | Current status |
|---|---|
| Audit program and synthetic tests | Included |
| Collection-manifest template | Included; unfilled |
| Analysis plan and integrity requirements | Proposed for author review |
| New numerical research findings | Not included |
| Final accepted analytical dataset | Not yet established |
| Statistical/figure-generation pipeline | Not implemented by this package |
| Immutable manuscript data release and DOI | Not yet created |
| Code/data licensing decision | Pending author/institutional approval |

## Proposed analytical scope

Keep the frozen, metadata-tree-linked cohort separate from the downloaded-assembly
annotation cohort and later exploratory extensions. Determine the final membership
and dates from the source manifests, not folder names or earlier narrative summaries.
Do not call a retrospectively developed rule prespecified or preregistered.

A processing package is not necessarily a biological collection. M_K4/M_K5/M_K6
labels identify local runs until source metadata establish their membership. PDG is
an organism-group identifier; PDS is an SNP-cluster identifier. Preserve accession
versions. A GCA/GCF accession represents an assembly, not automatically an independent
biological isolate. See the NCBI source in `docs/SOURCES.md`.

## Evidence and analysis products

The audit produces `QC_REPORT.md`, `package_inventory.csv`, `qc_issues.csv`,
`log_review.csv`, `cross_package_duplicates.csv`, `within_package_conflicts.csv`,
`unresolved_inputs.csv`, `unexpected_result_identifiers.csv`,
`collection_manifest_TO_COMPLETE.csv`, and provisional main-output tables.
`nonconflicting_main_records.tsv` means agreement within the package records;
it does not establish biological correctness, globally unique isolates, or publication
readiness. No missing gene calls are inferred from logs.

All unreviewed audit folders stay local under `outputs/`. Only deliberately reviewed
and appropriately licensed outputs should later be copied to `release_data/` and
committed. A passing test suite validates synthetic software behaviour, not the
actual study inputs or biological claims.

## Interpretation boundaries

Do not infer prevalence, direct transmission, clinical susceptibility, treatment
response, experimentally confirmed hypervirulence, or plasmid co-localization from
these annotation summaries alone. A shell/path error is not a species determination.
Missing output is not an absent gene. Preserve low-confidence/truncation flags and
verify definitions against the actual software and database versions used.

## Reproducibility and citation

Before the submission release, document a frozen manifest, input checksums, exact
commands, environment/dependency versions, mapping rules, missing-data decisions,
and the source table/script supporting every manuscript result. Archive the release
in an appropriate DOI-issuing repository and cite its exact version.

`CITATION.cff` describes this developing software project; it is not a citation to an
accepted article. Add verified contributors, version, date, and DOI when a release
exists. No DOI, ORCID, approved licence, or acceptance status is invented here.

## Rights and privacy

No code/data licence has been selected by generating this package. Confirm rights
before applying licences, and retain the attribution and terms of all third-party
sources. `.gitignore` reduces accidental Git commits of local data and credentials;
it is not a privacy scanner and must not be relied on for manual browser uploads.
No raw result archives or patient-level information are included in this package.
