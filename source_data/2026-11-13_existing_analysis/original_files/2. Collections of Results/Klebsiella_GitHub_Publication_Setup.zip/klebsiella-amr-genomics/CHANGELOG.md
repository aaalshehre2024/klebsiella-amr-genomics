# Change log

## Publication-setup kit — 2 November 2026

Expanded repository documentation and added citation metadata, a portable nonempty
test runner, and a local audit wrapper. Original `audit_results.py` version 0.1.0 and
its synthetic test file are unchanged from the previous starter. Added no research
results and made no changes to GitHub. This is not a scientific data release.
