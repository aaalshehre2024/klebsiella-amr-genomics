# Local setup and optional GitHub publishing

## Local extraction

Download `Klebsiella_GitHub_Analysis_Starter.zip` to Windows Downloads. In Ubuntu:

```bash
cd ~
unzip -n /mnt/c/Users/abu-r/Downloads/Klebsiella_GitHub_Analysis_Starter.zip
cd ~/klebsiella-amr-genomics
python3 -m unittest discover -s tests -v
```

In Windows, make `C:\Users\abu-r\Downloads\Klebsiella_results_for_paper` and copy
the approved/latest FINAL RESULT ZIPs into it. Do not mix old and superseded exports.
Do not include genome-download ZIPs or the starter ZIP itself.

```bash
cd ~/klebsiella-amr-genomics
find /mnt/c/Users/abu-r/Downloads/Klebsiella_results_for_paper -maxdepth 1 -type f -iname '*.zip' -exec cp -n -- {} input_raw/ \;
python3 scripts/audit_results.py --input-dir input_raw --output-dir outputs/audit_001
cat outputs/audit_001/QC_REPORT.md
```

Change the output directory for later audits. If you replace a result archive,
replace the corresponding file in `input_raw` deliberately and record the revision;
`cp -n` will not overwrite an existing input copy.

## Optional: publish code and reviewed audit text to a NEW private repository

These commands change your GitHub account only when YOU run them. The generated
starter did not create a repository. Check the proposed repository name and the
files before proceeding. Authentication belongs in the GitHub browser/device flow,
never in a chat or a project file.

```bash
sudo apt update
sudo apt install -y git gh unzip
gh auth login --hostname github.com --git-protocol https --web
gh auth setup-git
gh api user --jq .login
```

Confirm that the printed login is `aaalshehre2024` before continuing. In GitHub's
email settings, find your GitHub-provided no-reply commit address. Configure the
local Git repository with your chosen author name and that address before committing.

```bash
cd ~/klebsiella-amr-genomics
git init -b main
git config user.name "Abdullateef Alshehri"
# Replace the value below with the no-reply address shown in GitHub email settings.
git config user.email "YOUR_GITHUB_NOREPLY_EMAIL"
git add README.md .gitignore scripts tests docs metadata manuscript outputs
git diff --cached --stat
git diff --cached --name-only
```

Review every staged file for privacy, credentials, unapproved data, and size. The
input ZIPs are ignored by default. After review:

```bash
git commit -m "Add Kleborate audit workflow and reviewed outputs"
gh repo create aaalshehre2024/klebsiella-amr-genomics --private --source=. --remote=origin --push
gh repo view --json nameWithOwner,url
```

Run `gh repo create` only once and only for a new repository. If it already exists,
stop and inspect its contents rather than overwriting or force-pushing anything.
To update a repository you already own and have cloned, review changes, commit,
then use a normal `git push`. Never use a force push for this workflow.

Authorize the new repository in the ChatGPT GitHub app settings, then provide
`aaalshehre2024/klebsiella-amr-genomics` and the explicit audit directory to read.
The existing `aaalshehre2024/aaalshehre2024` repository is your profile repository;
leave it separate from the research project.
