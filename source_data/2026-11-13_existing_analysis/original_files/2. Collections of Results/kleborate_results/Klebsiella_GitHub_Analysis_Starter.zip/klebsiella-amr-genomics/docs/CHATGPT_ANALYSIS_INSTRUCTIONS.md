# Instructions for ChatGPT: audit first, then analysis and manuscript

Use the authorized repository `aaalshehre2024/klebsiella-amr-genomics` only after it
has actually been created and the relevant data have been uploaded. Read README.md,
the completed collection manifest and the newest explicitly designated audit report.
Do not assume the numerically last or largest archive is the approved one. Request
missing raw evidence only when required, and clearly distinguish unknowns from zero.

This is the Klebsiella pneumoniae database-derived genomic project, not the separate
E. coli/Shigella genotype–phenotype paper and not the bachelor's student project.
The intended journal is Antibiotics (MDPI). Keep source-derived findings separate
from literature-based interpretation and label unperformed analyses as proposals.

First reconcile records, assembly accessions including versions, exact duplicates,
GenBank/RefSeq pairs, repeat runs and overlapping collections. Verify that main
output records belong to the relevant frozen metadata. Distinguish SNP-cluster
PDS identifiers from PDG k-mer-group identifiers. Keep different snapshots and
primary versus extended cohorts identifiable. A technical split is not a new cohort.
Do not silently replace earlier frozen collections with newer collection versions.

Audit unavailable assemblies, incomplete result packages, truncated rows, output
conflicts, mixed run folders, species calls, quality flags and tool/database versions.
Never infer a biological species exclusion from a shell syntax error. Recover
full output tables before using fields not printed in batch logs. Do not treat
missing AMR or virulence output as absence. Interpret raw Kleborate allele suffixes,
frameshift/fragment flags and confidence fields according to the version actually
used. Preserve raw tokens and document derived variables separately.

After the audit, propose an explicit analysis plan and produce collection-level
counts, feature-specific denominators, ST/K/O distributions, allele- and family-level
carbapenemase profiles, and separate Kleborate resistance and virulence score
summaries. Define co-detection/convergence rules before calculating them and retain
uncertain and truncated calls separately. Do not equate yersiniabactin alone with
hypervirulence, or gene co-detection with plasmid co-location. Do not conflate the
custom NCBI architecture index with Kleborate's built-in score. Check rather than
invent the published definitions of those scores.

Link annotation tables to frozen Newick trees only after exact identifier matching.
Keep trees from different SNP clusters separate. Quantify uncertainty and sampling
structure where supported; do not add bootstrap tests, entropy analyses, model
validation or causal claims to Methods unless actually performed and documented.

Draft Results only from audited tables and provide the file/table behind each
reported number. Write Materials and Methods section 4 from the recorded workflow,
not an idealized workflow. Use placeholders for unknown versions/dates and verify
literature citations from primary sources. Do not claim clinical, geographic or
population prevalence; outbreak transmission; functional virulence; phenotype
prediction accuracy; plasmid co-location; or external validation without appropriate
evidence. Provide a transparent limitations and reproducibility section.
