# Manuscript drafting gate

Do not fill numerical Results from earlier chat summaries alone. Begin with the
QC report and an approved collection manifest. Proposed sequence: cohort/provenance
and denominators; ST/K/O profiles; carbapenemase architectures; score distributions;
carefully defined resistance–virulence co-detection; verified within-cluster tree
mapping. Introduction is supported by verified literature; Methods describe work
actually performed. Exact counts, cohort membership, dates, software versions and
statistical tests remain unresolved until the audit is approved.
