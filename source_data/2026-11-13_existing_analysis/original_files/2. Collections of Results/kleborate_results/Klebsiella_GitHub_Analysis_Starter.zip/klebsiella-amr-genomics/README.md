# Klebsiella AMR genomics: audit-first manuscript project

Working research direction: **Database-Derived Genomic Mapping of Carbapenemase,
Multidrug-Resistance, and Virulence Architectures across Selected Klebsiella
pneumoniae SNP-Cluster Collections**. Intended journal: *Antibiotics* (MDPI).

This is a starter analysis repository, not a completed analysis or a final paper.
No user result data are included in this starter. It contains an audit script,
synthetic tests, a collection manifest template and manuscript instructions.
No GitHub repository has been created or changed by generating this package.

## Run locally in Ubuntu/WSL

Python 3.9 or later is sufficient; the audit uses the standard library only.
It does not install, upgrade, or rerun Kleborate.

Put only the latest intended FINAL RESULT ZIP for each run into `input_raw/`.
Do not add individual NCBI genome ZIPs, old superseded result packages, or a master
archive containing other ZIPs. The audit reads the ZIPs directly, not nested ZIPs.
Keep original archive names and retain the source archives unchanged.

```bash
python3 -m unittest discover -s tests -v
python3 scripts/audit_results.py --input-dir input_raw --output-dir outputs/audit_001
cat outputs/audit_001/QC_REPORT.md
```

For another audit, choose a new output directory such as `outputs/audit_002`.
Existing output directories are not overwritten. The original data are read-only.

## What the program does

It inventories all readable Kleborate main-output tables and hAMRonization tables
inside each selected ZIP. It records source archive hashes, file names, available
versions and row counts; flags malformed rows and conflicting results; matches
input and output assembly keys where an input list is supplied; and reports
cross-package repeated assembly accessions. It retains all readable main rows with
provenance and separately exports nonconflicting per-package main records.

It also creates preliminary distributions of literal species, ST, K-locus, O-locus,
O-type, confidence, resistance-score, virulence-score and QC-warning values.
It does NOT classify raw gene tokens as biologically functional or infer missing
values from logs. It does not combine hAMRonization rows or interpret resistance
mechanisms. All summaries are provisional until the cohort and assay rules are
reviewed.

`nonconflicting_main_records.tsv` means consistent among the source records within
a package. It does not mean scientifically validated, representative, globally
deduplicated or ready for publication.

## Important outputs

`QC_REPORT.md` is the starting point. `package_inventory.csv` holds counts and
SHA-256 hashes. `output_file_inventory.csv` records the individual output layers
and reported versions. `qc_issues.csv`, `log_review.csv`,
`within_package_conflicts.csv`, `cross_package_duplicates.csv`,
`unresolved_inputs.csv` and `unexpected_result_identifiers.csv` support review.

`main_rows_with_provenance.tsv` retains raw main records, and
`nonconflicting_main_records.tsv` provides provisional per-package records.
`preliminary_raw_value_distributions.csv` summarizes literal output values.
`collection_manifest_TO_COMPLETE.csv` must be completed from frozen NCBI source
metadata before package labels can be used as scientific cohort identifiers.

## Interpretation boundaries

A package/run is not necessarily a separate SNP cluster. In particular, split runs
such as M_K4, M_K5 and M_K6 may be technical subsets of the same source group.
A PDG identifier must not silently be relabelled as a PDS SNP-cluster identifier.
Versions are retained: different PDS or assembly versions require reconciliation.
Filename numbers are not verified sample counts. A versioned GCA/GCF accession is
an assembly identifier, not automatically a unique biological isolate.
GenBank/RefSeq paired assemblies require a correspondence table; the script does
not infer equivalence merely by deleting the GCA/GCF prefix.

A shell syntax error (including problems with spaces or parentheses in paths) is
not evidence that an assembly belongs to another species. A logged species-check
failure requires review of technical execution and valid species calls before a
biological exclusion is accepted. Missing main or hAMRonization tables are missing
evidence, not negative findings. Do not fill missing K/O or virulence fields from
sparse log rows.

Original NCBI metadata/tree analysis and downloaded-assembly Kleborate analysis
must retain separate eligibility definitions and denominators. Record original
export dates separately from subsequent assembly-download/analysis dates. Do not
state that a result from an updated collection belongs to an earlier frozen tree
without accession-level verification.

## GitHub and privacy

Use a separate private research repository initially. The `.gitignore` prevents
accidental commits of local result ZIPs, genome sequences and common secret-file
formats, but it cannot detect every secret. Review every staged file before a push.
Only push approved non-identifiable data. Raw result ZIPs remain local by default.
GitHub storage and connection are not a substitute for a frozen research archive.
No scientific release licence has been chosen; decide code and data licences
before public release after checking source terms.

The connected GitHub app can retrieve permitted text content. Repository access
does not execute this script in your Ubuntu terminal. Run the audit locally first,
then upload/push the approved text outputs or attach the result ZIPs directly in
ChatGPT. Use the prompts in `docs/CHATGPT_ANALYSIS_INSTRUCTIONS.md`.

## Online documentation checked when preparing this starter

- https://help.openai.com/en/articles/11145903-connecting-github-to-chatgpt
- https://cli.github.com/manual/gh_auth_login
- https://cli.github.com/manual/gh_repo_create
- https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github

This starter is a transparent processing aid. Synthetic tests do not validate the
biology, original cohort selection, software behaviour or manuscript conclusions.
