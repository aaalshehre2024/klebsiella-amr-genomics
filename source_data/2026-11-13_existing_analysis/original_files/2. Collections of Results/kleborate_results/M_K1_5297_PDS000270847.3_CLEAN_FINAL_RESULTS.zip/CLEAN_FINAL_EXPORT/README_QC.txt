PDS000270847.3 Kleborate clean export
Unique FASTA input: 846
Successfully analyzed: 843
Not included: 3

The clean analytical output contains only successfully analyzed genomes.
