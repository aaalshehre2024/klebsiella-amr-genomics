import sys
from pathlib import Path

name = sys.argv[1]
target = Path("final")/name
temp = target.with_suffix(".partial")
header = None
count = 0

with temp.open("wb") as out:
    for b in sorted(Path("batch_lists").glob("batch_*")):
        a = Path((Path("batches")/b.name/"VERIFIED").read_text().strip())
        p = a/"out"/name
        if not p.exists():
            excluded = set((a/"excluded.txt").read_text().splitlines())
            planned = {Path(x).stem for x in b.read_text().splitlines()}
            if excluded == planned:
                continue
            raise SystemExit("STOP: missing "+str(p))

        with p.open("rb") as f:
            h = f.readline().rstrip(b"\r\n")
            if not h:
                raise SystemExit("STOP: empty table: "+str(p))
            if header is None:
                header = h
                out.write(h+b"\n")
            if h != header:
                raise SystemExit("STOP: different headers: "+str(p))
            for line in f:
                row = line.rstrip(b"\r\n")
                if row==h or row.count(b"\t")!=h.count(b"\t"):
                    raise SystemExit("STOP: malformed row: "+str(p))
                out.write(row+b"\n")
                count += 1

if header is None:
    raise SystemExit("STOP: no KpSC table available.")
temp.replace(target)
print(target, "data rows:",count)
