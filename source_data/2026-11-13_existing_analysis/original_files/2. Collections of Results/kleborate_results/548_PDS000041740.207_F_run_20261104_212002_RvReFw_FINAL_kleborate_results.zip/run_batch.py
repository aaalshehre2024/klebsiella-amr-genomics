import csv, os, re, subprocess, sys, tempfile
from pathlib import Path

def table(p, col):
    if not p.exists():
        return []
    with p.open(newline="") as f:
        r = csv.DictReader(f,delimiter="\t")
        if col not in (r.fieldnames or []):
            raise SystemExit("STOP: invalid header: "+str(p))
        return list(r)

v = subprocess.check_output(["kleborate","--version"],stderr=subprocess.STDOUT,text=True)
if not re.search(r"(?im)^\s*(?:Kleborate\s+)?v?3\.2\.4\s*$",v):
    raise SystemExit("STOP: expected Kleborate 3.2.4")

b = Path(sys.argv[1])
files = b.read_text().splitlines()
want = {Path(p).stem for p in files}
if not (1 <= len(files) <= 100 and len(want)==len(files)):
    raise SystemExit("STOP: invalid batch")

base = Path("batches")/b.name
base.mkdir(exist_ok=True)
ok = base/"VERIFIED"
if ok.exists():
    print("Already verified:",b.name)
    sys.exit(0)

a = Path(tempfile.mkdtemp(dir=base,prefix="try_"))
out = a/"out"
log = a/"run.log"
print(f"Running {b.name}: {len(files)} assemblies. Log: {log}",flush=True)

with log.open("w") as f:
    r = subprocess.run(
        ["kleborate","-a",*files,"-o",str(out),"-p","kpsc","--trim_headers"],
        stdout=f,stderr=subprocess.STDOUT,
        env=dict(os.environ,PYTHONUNBUFFERED="1",PYTHONHASHSEED="0"))
if r.returncode:
    raise SystemExit(f"STOP: Kleborate exit {r.returncode}; see {log}")

text = log.read_text(errors="replace")
if "Error encountered while processing " in text:
    raise SystemExit("STOP: processing error; see "+str(log))

main = table(out/"klebsiella_pneumo_complex_output.txt","strain")
hfile = out/"klebsiella_pneumo_complex_hAMRonization_output.txt"
if main and not hfile.is_file():
    raise SystemExit("STOP: missing hAMRonization file; see "+str(a))
ham = table(hfile,"Input_file_name")

ids = {x["strain"] for x in main}
hitids = {x["Input_file_name"] for x in ham}
skips = {Path(x).stem for x in re.findall(r"^Assembly (.+) failed in check is_kp_complex\.$",text,re.M)}
if len(ids)!=len(main) or ids & skips or (ids | skips)!=want or not hitids <= ids:
    raise SystemExit("STOP: input/output identifiers do not reconcile; see "+str(a))

for x in main:
    if x["strain"] not in hitids and any(x.get(k,"-") not in ("","-") for k in ("Bla_Carb_acquired","Bla_ESBL_acquired","Bla_acquired","AGly_acquired")):
        raise SystemExit("STOP: main table reports AMR calls but no hAMRonization rows for "+x["strain"])

(a/"excluded.txt").write_text("".join(x+"\n" for x in sorted(skips)))
ok.write_text(str(a.resolve())+"\n")
print(f"VERIFIED: {len(ids)} analyzed; {len(skips)} explicit species exclusions; {len(ham)} determinant rows.")
